<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(config('app.name', 'Support Ticket System')); ?></title>

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="min-h-screen bg-[#111111] text-white antialiased">

    <!-- flash messages -->
    <?php if(session('success') || session('error')): ?>
        <div
            id="flash-message"
            class="fixed right-5 top-5 z-50 max-w-sm rounded-xl border border-white/10 bg-[#1a1a1a] px-5 py-4 text-sm font-medium text-white shadow-xl"
        >
            <?php if(session('success')): ?>
                <div class="text-green-400">
                    <?php echo e(session('success')); ?>

                </div>
            <?php else: ?>
                <div class="text-red-400">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if (! empty(trim($__env->yieldContent('dashboard')))): ?>
        <?php echo $__env->yieldContent('dashboard'); ?>
    <?php else: ?>
        <!-- standard application header -->
        

        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>

    <!-- auto hide flash message -->
    <script>
        setTimeout(() => {
            const flashMessage = document.getElementById('flash-message');

            if (flashMessage) {
                flashMessage.remove();
            }
        }, 3000);
    </script>

</body>
</html><?php /**PATH C:\laragon\www\support-ticket-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>