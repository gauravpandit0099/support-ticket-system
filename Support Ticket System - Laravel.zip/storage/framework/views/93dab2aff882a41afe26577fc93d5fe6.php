

<?php $__env->startSection('dashboard'); ?>
    <div class="min-h-screen bg-[#111111] text-white">
        <div class="flex min-h-screen">

            <!-- reusable admin sidebar -->
            <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            
            <main class="min-w-0 flex-1">

                
                <header class="flex items-center justify-between border-b border-white/10 px-6 py-5 sm:px-8">
                    <div>
                        <h2 class="text-xl font-semibold tracking-tight">
                            Edit Ticket
                        </h2>
                        <p class="mt-1 text-sm text-gray-500">
                            Update ticket information
                        </p>
                    </div>

                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit"
                                class="rounded-lg border border-white/10 px-4 py-2 text-sm font-medium text-gray-300 transition hover:bg-white/5 hover:text-white">
                            Logout
                        </button>
                    </form>
                </header>

                
                <div class="px-6 py-8 sm:px-8">

                    
                    <?php if(session('success')): ?>
                        <div class="mb-6 rounded-lg border border-green-500/20 bg-green-500/10 px-4 py-3 text-sm text-green-400">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('error')): ?>
                        <div class="mb-6 rounded-lg border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400">
                            <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if($errors->any()): ?>
                        <div class="mb-6 rounded-lg border border-red-500/20 bg-red-500/10 px-4 py-3 text-sm text-red-400">
                            <ul class="space-y-1">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="max-w-3xl">

                        
                        <a href="<?php echo e(route('admin.tickets.index')); ?>"
                           class="mb-6 inline-flex items-center text-sm text-gray-400 transition hover:text-white">
                            ← Back to Support Tickets
                        </a>

                        
                        <div class="rounded-xl border border-white/10 bg-[#151515] p-6 sm:p-8">

                            <div class="mb-7">
                                <p class="text-xs font-medium uppercase tracking-wider text-gray-500">
                                    Ticket #<?php echo e($ticket->id); ?>

                                </p>
                                <h3 class="mt-2 text-lg font-semibold text-white">
                                    Update Ticket
                                </h3>
                            </div>

                            <form method="POST"
                                  action="<?php echo e(route('admin.tickets.update', $ticket->id)); ?>"
                                  class="space-y-6">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>

                                
                                <div>
                                    <label for="title" class="mb-2 block text-sm font-medium text-gray-300">
                                        Title
                                    </label>
                                    <input id="title"
                                           type="text"
                                           name="title"
                                           value="<?php echo e(old('title', $ticket->title)); ?>"
                                           maxlength="255"
                                           required
                                           class="w-full rounded-lg border border-white/10 bg-[#111111] px-4 py-3 text-sm text-white outline-none transition placeholder:text-gray-600 focus:border-white/30"
                                           placeholder="Enter ticket title">
                                </div>

                                
                                <div>
                                    <label for="description" class="mb-2 block text-sm font-medium text-gray-300">
                                        Description
                                    </label>
                                    <textarea id="description"
                                              name="description"
                                              rows="7"
                                              maxlength="5000"
                                              required
                                              class="w-full resize-none rounded-lg border border-white/10 bg-[#111111] px-4 py-3 text-sm text-white outline-none transition placeholder:text-gray-600 focus:border-white/30"
                                              placeholder="Enter ticket description"><?php echo e(old('description', $ticket->description)); ?></textarea>
                                </div>

                                
                                <div>
                                    <label for="priority" class="mb-2 block text-sm font-medium text-gray-300">
                                        Priority
                                    </label>
                                    <select id="priority"
                                            name="priority"
                                            required
                                            class="w-full rounded-lg border border-white/10 bg-[#111111] px-4 py-3 text-sm text-white outline-none transition focus:border-white/30">
                                        <option value="low" <?php if(old('priority', $ticket->priority) === 'low'): echo 'selected'; endif; ?>>
                                            Low
                                        </option>
                                        <option value="medium" <?php if(old('priority', $ticket->priority) === 'medium'): echo 'selected'; endif; ?>>
                                            Medium
                                        </option>
                                        <option value="high" <?php if(old('priority', $ticket->priority) === 'high'): echo 'selected'; endif; ?>>
                                            High
                                        </option>
                                        <option value="urgent" <?php if(old('priority', $ticket->priority) === 'urgent'): echo 'selected'; endif; ?>>
                                            Urgent
                                        </option>
                                    </select>
                                </div>

                                
                                <div class="rounded-lg border border-white/10 bg-white/[0.02] px-4 py-3">
                                    <div class="flex items-center justify-between gap-4">
                                        <span class="text-sm text-gray-400">
                                            Current Status
                                        </span>
                                        <span class="text-sm font-medium text-white">
                                            <?php echo e(str_replace('_', ' ', ucfirst($ticket->status))); ?>

                                        </span>
                                    </div>
                                </div>

                                
                                <div class="flex flex-col gap-3 pt-2 sm:flex-row sm:justify-end">
                                    <a href="<?php echo e(route('admin.tickets.index')); ?>"
                                       class="rounded-lg border border-white/10 px-5 py-3 text-center text-sm font-medium text-gray-300 transition hover:bg-white/5 hover:text-white">
                                        Cancel
                                    </a>
                                    <button type="submit"
                                            class="rounded-lg bg-white px-5 py-3 text-sm font-semibold text-slate-900 transition hover:bg-slate-200">
                                        Save Changes
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\support-ticket-system\resources\views/admin/tickets/admin-ticket-edit.blade.php ENDPATH**/ ?>